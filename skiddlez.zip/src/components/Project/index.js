import Project from './Project';

export default Project;
