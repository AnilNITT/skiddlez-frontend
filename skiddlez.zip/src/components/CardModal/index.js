import CardModal from './CardModal';

export default CardModal;
