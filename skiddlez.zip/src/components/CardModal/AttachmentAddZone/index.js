import AttachmentAddZone from './AttachmentAddZone';

export default AttachmentAddZone;
