import Task from './Tasks';

export default Task;
