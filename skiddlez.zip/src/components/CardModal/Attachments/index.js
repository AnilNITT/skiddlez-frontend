import Attachments from './Attachments';

export default Attachments;
