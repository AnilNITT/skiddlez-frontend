import BoardActions from './BoardActions';

export default BoardActions;
