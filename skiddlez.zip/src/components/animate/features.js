import { domMax } from 'framer-motion/dist/framer-motion';

export default domMax;
