import GeneralPane from './GeneralPane';

export default GeneralPane;
