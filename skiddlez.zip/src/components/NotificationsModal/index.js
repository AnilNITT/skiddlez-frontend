import NotificationsModal from './NotificationsModal';

export default NotificationsModal;
