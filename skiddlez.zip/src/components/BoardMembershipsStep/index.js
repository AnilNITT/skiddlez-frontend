import BoardMembershipsStep from './BoardMembershipsStep';

export default BoardMembershipsStep;
