import Fixed from './Fixed';

export default Fixed;
