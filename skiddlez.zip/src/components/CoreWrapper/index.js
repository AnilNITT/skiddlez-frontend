import CoreWrapper from './CoreWrapper';

export default CoreWrapper;
