import BoardKanban from './BoardKanban';

export default BoardKanban;
