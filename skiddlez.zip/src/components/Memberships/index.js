import Memberships from './Memberships';

export default Memberships;
