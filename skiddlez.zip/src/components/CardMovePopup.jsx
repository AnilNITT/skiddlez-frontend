import { withPopup } from '../lib/popup';

import CardMoveStep from './CardMoveStep';

export default withPopup(CardMoveStep);
