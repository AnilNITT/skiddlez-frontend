import { withPopup } from '../lib/popup';

import BoardMembershipsStep from './BoardMembershipsStep';

export default withPopup(BoardMembershipsStep);
