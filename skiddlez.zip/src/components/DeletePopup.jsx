import { withPopup } from '../lib/popup';

import DeleteStep from './DeleteStep';

export default withPopup(DeleteStep);
