import Boards from './Boards';

export default Boards;
