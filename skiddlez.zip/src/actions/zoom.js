import ActionTypes from "../constants/ActionTypes";

export const zoomIn = () => ({
    type : ActionTypes.ZOOM_IN
});

export const zoomOut = () => ({
    type : ActionTypes.ZOOM_OUT
});