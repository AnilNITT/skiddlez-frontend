import ActionTypes from '../constants/ActionTypes';

/* Events */

// eslint-disable-next-line import/prefer-default-export
export const coreInitialized = () => ({
  type: ActionTypes.CORE_INITIALIZED,
  payload: {},
});
