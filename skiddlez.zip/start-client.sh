#!/bin/bash

#API_URL=http://api:1337
#cd ./client
yarn install
yarn build
yarn start
