# Planka client
"build": "react-scripts  --openssl-legacy-provider build",
